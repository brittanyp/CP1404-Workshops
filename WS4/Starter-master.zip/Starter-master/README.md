# Starter
Code repository with basic starter Python code for CP1404/CP5632 @ JCU
